package Symbol;

public enum Type {
    VOID,
    INT
}

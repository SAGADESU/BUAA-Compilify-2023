package Symbol;

public enum Kind {
    CONST,
    VAR,
    FUNC,
    PARAM
}
